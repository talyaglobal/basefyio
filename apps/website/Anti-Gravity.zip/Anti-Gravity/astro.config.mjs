import mdx from '@astrojs/mdx';
import react from '@astrojs/react';
import sitemap from '@astrojs/sitemap';
import { defineConfig } from 'astro/config';

// Get site URL from environment variable with fallback
const siteUrl =
  process.env.PUBLIC_SITE_URL || import.meta.env.PUBLIC_SITE_URL || 'https://antigravity.hilaltechnologic.com';

// https://astro.build/config
export default defineConfig({
  // Use environment variable for site URL (production-ready)
  site: siteUrl,
  integrations: [react(), mdx(), sitemap()],
  markdown: {
    shikiConfig: {
      theme: 'github-dark',
      wrap: true,
    },
  },
  vite: {
    ssr: {
      noExternal: ['@radix-ui/*'],
    },
  },
});
