/**
 * Site Configuration
 *
 * Central configuration for the Anti-Gravity theme.
 * Uses environment variables for production flexibility.
 */

// Get site URL from environment variable with fallback for local development
const getSiteUrl = (): string => {
  // Check for Astro's environment variable
  if (typeof import.meta !== 'undefined' && import.meta.env?.PUBLIC_SITE_URL) {
    return import.meta.env.PUBLIC_SITE_URL;
  }
  // Fallback for local development
  return 'https://antigravity.hilaltechnologic.com';
};

export const siteConfig = {
  name: 'Anti-Gravity',
  description:
    'A modern, minimal multi-purpose theme for Astro. Built with Linear-inspired design principles.',
  url: getSiteUrl(),
  ogImage: '/og-image.png',
  author: 'Hilal Technologic',
  email: 'hello@hilaltechnologic.com',

  // Navigation links
  navLinks: [
    { label: 'Features', href: '/features' },
    { label: 'Pricing', href: '/pricing' },
    { label: 'Blog', href: '/blog' },
    { label: 'Docs', href: '/docs' },
    { label: 'About', href: '/about' },
  ],

  // Footer navigation
  footerLinks: {
    product: [
      { label: 'Features', href: '/features' },
      { label: 'Pricing', href: '/pricing' },
      { label: 'Changelog', href: '/changelog' },
      { label: 'Roadmap', href: '/roadmap' },
    ],
    company: [
      { label: 'About', href: '/about' },
      { label: 'Blog', href: '/blog' },
      { label: 'Contact', href: '/contact' },
    ],
    resources: [
      { label: 'Documentation', href: '/docs' },
      { label: 'Changelog', href: '/changelog' },
      {
        label: 'License',
        href: 'https://github.com/hilaltechnologic/anti-gravity/blob/main/LICENSE.md',
      },
    ],
    legal: [
      { label: 'Privacy Policy', href: '/legal/privacy' },
      { label: 'Terms of Service', href: '/legal/terms' },
    ],
  },

  // Social links - Update these with your actual social media accounts
  socials: {
    twitter: 'https://twitter.com/hilaltechnologic',
    github: 'https://github.com/hilaltechnologic',
    discord: '#', // Add your Discord invite link
    linkedin: 'https://linkedin.com/company/hilaltechnologic',
  },
};

// Pricing plans - Theme License Tiers
export const pricingPlans = [
  {
    id: 'personal',
    name: 'Personal',
    description: 'Perfect for personal projects and learning.',
    price: {
      monthly: 49, // One-time payment
      yearly: 49,
    },
    currency: 'USD',
    features: [
      'Full source code',
      '1 end product',
      '1 developer',
      'Lifetime updates',
      'Email support (48hr)',
      'Documentation access',
    ],
    limitations: ['Cannot be used for client work'],
    cta: 'Buy License',
    ctaLink: '/contact?plan=personal',
    popular: false,
  },
  {
    id: 'team',
    name: 'Team',
    description: 'For agencies and teams building client projects.',
    price: {
      monthly: 149, // One-time payment
      yearly: 149,
    },
    currency: 'USD',
    features: [
      'Full source code',
      'Unlimited end products',
      'Up to 10 developers',
      'Lifetime updates',
      'Priority support (24hr)',
      'Client projects allowed',
      'Documentation access',
    ],
    limitations: [],
    cta: 'Buy License',
    ctaLink: '/contact?plan=team',
    popular: true,
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    description: 'For large organizations and SaaS applications.',
    price: {
      monthly: 499, // One-time payment
      yearly: 499,
    },
    currency: 'USD',
    features: [
      'Full source code',
      'Unlimited end products',
      'Unlimited developers',
      'Lifetime updates',
      'Dedicated support contact',
      'SaaS application rights',
      'Extended license terms',
      'Priority onboarding',
    ],
    limitations: [],
    cta: 'Contact Sales',
    ctaLink: '/contact?plan=enterprise',
    popular: false,
  },
];

// Features list
export const features = [
  {
    id: 'speed',
    title: 'Lightning Fast',
    description:
      'Built on Astro for optimal performance. Zero JavaScript by default, islands architecture for interactivity.',
    icon: 'Zap',
  },
  {
    id: 'design',
    title: 'Beautiful Design',
    description:
      'Linear-inspired aesthetics with clean typography, subtle animations, and thoughtful spacing.',
    icon: 'Palette',
  },
  {
    id: 'responsive',
    title: 'Fully Responsive',
    description: 'Looks great on every device, from mobile phones to ultra-wide monitors.',
    icon: 'Smartphone',
  },
  {
    id: 'accessible',
    title: 'Accessible',
    description:
      'Built with accessibility in mind. Keyboard navigation, screen reader support, and WCAG compliance.',
    icon: 'Accessibility',
  },
  {
    id: 'dark-mode',
    title: 'Dark Mode',
    description:
      'Beautiful light and dark themes with system preference detection and smooth transitions.',
    icon: 'Moon',
  },
  {
    id: 'customizable',
    title: 'Customizable',
    description: 'Easy to customize with CSS variables and Tailwind. Make it yours in minutes.',
    icon: 'Settings',
  },
  {
    id: 'seo',
    title: 'SEO Optimized',
    description: 'Built-in SEO best practices, meta tags, Open Graph, and structured data support.',
    icon: 'Search',
  },
  {
    id: 'typescript',
    title: 'TypeScript',
    description:
      'Full TypeScript support for type-safe development and better developer experience.',
    icon: 'Code',
  },
];

// Testimonials - DEMO CONTENT: Replace with your own customer testimonials
export const testimonials = [
  {
    id: 1,
    content:
      'Anti-Gravity transformed our website. The design is clean, modern, and our conversion rates have improved significantly.',
    author: 'Sarah Chen',
    role: 'CEO',
    company: 'TechStart',
    avatar: '/avatars/avatar-1.jpg',
  },
  {
    id: 2,
    content:
      "The best Astro theme I've used. The attention to detail in the design system is impressive. Highly recommended.",
    author: 'Marcus Johnson',
    role: 'Lead Developer',
    company: 'DevStudio',
    avatar: '/avatars/avatar-2.jpg',
  },
  {
    id: 3,
    content:
      'We shipped our new marketing site in half the time thanks to Anti-Gravity. The components are well-designed and easy to customize.',
    author: 'Emily Rodriguez',
    role: 'Product Manager',
    company: 'ScaleUp',
    avatar: '/avatars/avatar-3.jpg',
  },
];

// FAQ items
export const faqItems = [
  {
    question: 'What is Anti-Gravity?',
    answer:
      'Anti-Gravity is a premium, modern multi-purpose theme built for Astro. It features a Linear-inspired design with clean typography, subtle animations, and a comprehensive component library.',
  },
  {
    question: 'What do I get with my purchase?',
    answer:
      'Every license includes the full source code, lifetime updates, documentation access, and email support. Team and Enterprise licenses allow use on multiple projects and for client work.',
  },
  {
    question: 'What technologies does it use?',
    answer:
      'Anti-Gravity is built with Astro, TypeScript, Tailwind CSS, and Radix UI. It follows best practices for performance, accessibility, and SEO.',
  },
  {
    question: 'Can I use it for client projects?',
    answer:
      'Yes! The Team and Enterprise licenses allow you to use Anti-Gravity for client projects. The Personal license is for your own personal projects only.',
  },
  {
    question: 'How do I customize the theme?',
    answer:
      'Anti-Gravity uses CSS variables and Tailwind for styling. You can easily customize colors, typography, spacing, and more by editing the configuration files. Check out our theming guide for details.',
  },
  {
    question: 'Is there support available?',
    answer:
      'Yes! All licenses include email support. Team licenses get 24-hour priority response, and Enterprise licenses include a dedicated support contact.',
  },
  {
  question: 'Do you offer refunds?',
  answer:
    'Due to the digital nature of this product, all sales are final.\n\n' +
    'Once the files have been downloaded, we are unable to offer refunds, exchanges, or cancellations.\n\n' +
    'However, refunds may be considered in the following cases:\n' +
    '- You were charged multiple times for the same purchase\n' +
    '- You accidentally purchased the wrong license edition\n' +
    '- The product is completely unusable due to a technical issue that cannot be resolved\n\n' +
    'If you experience any issues, please contact us with:\n' +
    '- Your Gumroad receipt\n' +
    '- A clear description of the problem\n\n' +
    'We are committed to providing support and ensuring the product works as described.',
  },
];

// Changelog entries
export const changelogEntries = [
  {
    version: '1.0.0',
    date: '2025-09-11',
    title: 'Initial Release',
    description: 'The first stable release of Anti-Gravity theme.',
    changes: [
      'Core component library',
      'Light and dark themes',
      'Full documentation',
      'Example pages and layouts',
      'Antigravity 3D animation',
    ],
    type: 'release' as const,
  },
];

// Roadmap items
export const roadmapItems = [
  {
    id: 1,
    title: 'Component Variants',
    description: 'More variants for existing components including sizes, colors, and styles.',
    status: 'in-progress' as const,
    quarter: 'Q4 2025',
  },
  {
    id: 2,
    title: 'Animation Library',
    description: 'Pre-built animation presets for common UI patterns.',
    status: 'planned' as const,
    quarter: 'Q4 2025',
  },
  {
    id: 3,
    title: 'E-commerce Templates',
    description: 'Product pages, cart, and checkout templates.',
    status: 'planned' as const,
    quarter: 'Q1 2026',
  },
  {
    id: 4,
    title: 'Dashboard Templates',
    description: 'Admin dashboard and analytics page templates.',
    status: 'planned' as const,
    quarter: 'Q1 2026',
  },
  {
    id: 5,
    title: 'Figma Design Kit',
    description: 'Complete Figma design system matching the code components.',
    status: 'considering' as const,
    quarter: 'Q2 2026',
  },
];

export type SiteConfig = typeof siteConfig;
export type PricingPlan = (typeof pricingPlans)[number];
export type Feature = (typeof features)[number];
export type Testimonial = (typeof testimonials)[number];
export type FAQItem = (typeof faqItems)[number];
export type ChangelogEntry = (typeof changelogEntries)[number];
export type RoadmapItem = (typeof roadmapItems)[number];
