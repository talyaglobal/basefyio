<div align="center">

# 🚀 Anti-Gravity

### A Modern, Minimal Multi-Purpose Theme for Astro

[![Astro](https://img.shields.io/badge/Astro-5.x-BC52EE?style=flat-square&logo=astro)](https://astro.build)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.x-3178C6?style=flat-square&logo=typescript)](https://www.typescriptlang.org)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.x-06B6D4?style=flat-square&logo=tailwindcss)](https://tailwindcss.com)
[![License](https://img.shields.io/badge/License-Commercial-orange?style=flat-square)](./LICENSE.md)
[![Version](https://img.shields.io/badge/Version-1.0.0-blue?style=flat-square)](./CHANGELOG.md)

Built with Linear-inspired design principles for SaaS products, startups, portfolios, and marketing sites.

[Live Demo](https://antigravity.hilaltechnologic.com) · [Documentation](./docs) · [Buy License](https://hilaltechnologic.com/anti-gravity)

![Anti-Gravity Preview](./public/og-image.png)

</div>

---

## ✨ Features

- **🚀 Performance First** - Built on Astro's islands architecture, ships zero JavaScript by default
- **🎨 Beautiful Design** - Linear-inspired aesthetics with clean typography and subtle animations
- **🌙 Dark Mode** - Light, dark, and system theme support with smooth transitions
- **♿ Accessible** - WCAG compliant with full keyboard navigation and screen reader support
- **📱 Responsive** - Looks great on all devices from mobile to ultra-wide monitors
- **🛠 Customizable** - Easy theming with CSS variables and Tailwind CSS
- **📝 Content Ready** - Blog and documentation support with MDX
- **🔍 SEO Optimized** - Meta tags, Open Graph, sitemap, and more

## 🚀 Quick Start

```bash
# After purchasing, download and extract the theme
unzip anti-gravity-theme.zip -d my-project

# Navigate to the project
cd my-project

# Install dependencies
npm install

# Start development server
npm run dev
```

Your site will be running at `http://localhost:4321`.

## 📁 Project Structure

```
├── public/              # Static assets
├── src/
│   ├── components/
│   │   ├── layout/      # Navbar, Footer, ThemeToggle
│   │   ├── sections/    # Hero, Features, Pricing, FAQ, CTA
│   │   └── ui/          # Button, Card, Badge, Input, etc.
│   ├── config/
│   │   └── site.ts      # Site configuration
│   ├── content/
│   │   ├── blog/        # Blog posts (MDX)
│   │   └── docs/        # Documentation (MDX)
│   ├── layouts/
│   │   └── BaseLayout.astro
│   ├── lib/
│   │   └── utils.ts     # Utility functions
│   ├── pages/           # Page routes
│   └── styles/
│       └── globals.css  # Global styles & tokens
├── astro.config.mjs     # Astro configuration
├── tailwind.config.mjs  # Tailwind configuration
└── package.json
```

## 📄 Pages Included

- `/` - Home (SaaS landing)
- `/features` - Features showcase
- `/pricing` - Pricing plans
- `/about` - About/Team page
- `/contact` - Contact form
- `/blog` - Blog listing
- `/blog/[slug]` - Blog post
- `/docs` - Documentation
- `/docs/[slug]` - Doc page
- `/changelog` - Version history
- `/roadmap` - Product roadmap
- `/legal/privacy` - Privacy policy
- `/legal/terms` - Terms of service
- `/404` - Not found page

## 🎨 Customization

### Colors

Edit `src/styles/globals.css` to change the color scheme:

```css
:root {
  --color-primary: #4f46e5;
  --color-primary-hover: #4338ca;
  /* ... */
}

.dark {
  --color-primary: #6366f1;
  --color-primary-hover: #818cf8;
  /* ... */
}
```

### Site Configuration

Edit `src/config/site.ts` to update site information:

```typescript
export const siteConfig = {
  name: 'Your Site Name',
  description: 'Your description',
  url: 'https://your-domain.com',
  // ...
};
```

See [THEMING.md](./THEMING.md) for detailed customization guide.

## 🧩 Components

### UI Components

| Component     | Description                                           |
| ------------- | ----------------------------------------------------- |
| `Button`      | Primary, secondary, ghost, destructive, link variants |
| `Card`        | Container with header, content, footer                |
| `Badge`       | Status labels and tags                                |
| `Input`       | Text input with validation                            |
| `Textarea`    | Multi-line text input                                 |
| `ThemeToggle` | Light/dark/system toggle                              |

### Section Components

| Component      | Description                                           |
| -------------- | ----------------------------------------------------- |
| `Hero`         | 4 variants: default, gradient, split, **antigravity** |
| `Features`     | Feature grid with icons                               |
| `Pricing`      | Pricing table with toggle                             |
| `FAQ`          | Accordion FAQ section                                 |
| `CTA`          | Call-to-action sections                               |
| `Testimonials` | Customer testimonials                                 |

### Animation Components

| Component           | Description                                 |
| ------------------- | ------------------------------------------- |
| `Antigravity`       | 3D particle animation with WebGL (Three.js) |
| `AntigravityIsland` | Astro wrapper for Antigravity animation     |

## 🎆 Antigravity Animation

The theme includes a signature **Antigravity** particle animation built with Three.js and React Three Fiber. This creates an interactive, mesmerizing visual effect that responds to cursor movement.

### Usage

```astro
---
import AntigravityIsland from '../components/animations/AntigravityIsland.astro';
---

<AntigravityIsland count={300} color="#6366f1" particleShape="capsule" height="400px" />
```

### Hero with Antigravity

```astro
<Hero
  variant="antigravity"
  title="Your Title"
  titleHighlight="Highlighted"
  description="Your description"
  antigravityOptions={{
    count: 400,
    color: '#6366f1',
    particleShape: 'capsule',
  }}
/>
```

### Props

| Prop            | Type    | Default | Description                              |
| --------------- | ------- | ------- | ---------------------------------------- |
| `count`         | number  | 300     | Number of particles                      |
| `color`         | string  | #6366f1 | Particle color (hex)                     |
| `particleShape` | string  | capsule | Shape: capsule, sphere, box, tetrahedron |
| `autoAnimate`   | boolean | true    | Auto-animate when mouse is idle          |
| `magnetRadius`  | number  | 10      | Magnetic attraction radius               |
| `ringRadius`    | number  | 7       | Ring formation radius                    |
| `waveSpeed`     | number  | 0.4     | Wave animation speed                     |
| `height`        | string  | 400px   | Container height                         |

### Demo

Visit `/demo/antigravity` to see all animation variants and configurations.

> **Note:** The animation requires WebGL support. A graceful fallback gradient is displayed on unsupported browsers.

## 📦 Tech Stack

- **[Astro](https://astro.build)** - Static site generator
- **[TypeScript](https://www.typescriptlang.org)** - Type safety
- **[Tailwind CSS](https://tailwindcss.com)** - Utility-first CSS
- **[Radix UI](https://www.radix-ui.com)** - Accessible primitives
- **[Three.js](https://threejs.org)** - 3D graphics library
- **[React Three Fiber](https://docs.pmnd.rs/react-three-fiber)** - React renderer for Three.js
- **[Lucide](https://lucide.dev)** - Icon library
- **[MDX](https://mdxjs.com)** - Markdown with components

## 🚀 Deployment

### Vercel

```bash
npm run build
# Deploy the `dist` folder
```

Or connect your repository for automatic deployments.

### Netlify

1. Connect your repository
2. Build command: `npm run build`
3. Publish directory: `dist`

### Cloudflare Pages

1. Connect your repository
2. Build command: `npm run build`
3. Build output directory: `dist`

## 📝 Scripts

| Command                | Description                  |
| ---------------------- | ---------------------------- |
| `npm run dev`          | Start development server     |
| `npm run build`        | Build for production         |
| `npm run preview`      | Preview production build     |
| `npm run typecheck`    | Run TypeScript type checking |
| `npm run lint`         | Run ESLint                   |
| `npm run lint:fix`     | Fix ESLint errors            |
| `npm run format`       | Format code with Prettier    |
| `npm run format:check` | Check code formatting        |
| `npm run clean`        | Clean build artifacts        |

## 📋 Requirements

- **Node.js** 18.x or higher
- **npm** 9.x or higher (or pnpm/yarn)
- Modern browser with WebGL support (for Antigravity animation)

## 🔧 Environment Variables

Copy `.env.example` to `.env` and configure:

```bash
# Site Configuration
PUBLIC_SITE_URL=https://your-domain.com

# Analytics (optional)
PUBLIC_GOOGLE_ANALYTICS_ID=
PUBLIC_PLAUSIBLE_DOMAIN=

# Contact Form (optional)
PUBLIC_FORM_ENDPOINT=

# Newsletter (optional)
PUBLIC_NEWSLETTER_ENDPOINT=
```

## 📊 Performance

Anti-Gravity is optimized for performance:

| Metric         | Score |
| -------------- | ----- |
| Performance    | 90+   |
| Accessibility  | 95+   |
| Best Practices | 95+   |
| SEO            | 95+   |

### Core Web Vitals

- **LCP** (Largest Contentful Paint): < 2.5s
- **FID** (First Input Delay): < 100ms
- **CLS** (Cumulative Layout Shift): < 0.1

## 🌐 Browser Support

| Browser       | Support   |
| ------------- | --------- |
| Chrome        | ✅ Latest |
| Firefox       | ✅ Latest |
| Safari        | ✅ Latest |
| Edge          | ✅ Latest |
| Chrome Mobile | ✅ Latest |
| Safari iOS    | ✅ Latest |

## 📁 What's Included

```
anti-gravity/
├── 📄 20 pre-built pages
├── 🧩 15+ UI components
├── 🎨 Complete design system
├── 🌙 Dark/Light/System themes
├── 📝 Blog with MDX support
├── 📚 Documentation system
├── 🎆 Antigravity 3D animation
├── ♿ Full accessibility support
├── 🔍 SEO optimization
├── 📱 Responsive design
└── 📋 Comprehensive documentation
```

## 💳 What You Get

Every license includes:

- ✅ **Full Source Code** - Complete Astro.js theme with all components
- ✅ **Lifetime Updates** - All future versions included
- ✅ **Documentation** - Comprehensive setup and customization guides
- ✅ **Email Support** - Based on your license tier
- ✅ **30-Day Guarantee** - Full refund if not satisfied

## 📄 License

This is a **commercial product** - see the [LICENSE.md](./LICENSE.md) for full terms.

| License    | Price | Use Cases                        |
| ---------- | ----- | -------------------------------- |
| Personal   | $49   | Personal projects, 1 developer   |
| Team       | $149  | Client work, up to 10 developers |
| Enterprise | $499  | SaaS apps, unlimited developers  |

## 📚 Documentation

- [README.md](./README.md) - This file
- [THEMING.md](./THEMING.md) - Customization guide
- [CONTRIBUTING.md](./CONTRIBUTING.md) - Contribution guidelines
- [CHANGELOG.md](./CHANGELOG.md) - Version history
- [DECISIONS.md](./DECISIONS.md) - Design decisions
- [QA_CHECKLIST.md](./QA_CHECKLIST.md) - Quality assurance checklist

## 🙏 Credits

- Design inspired by [Linear](https://linear.app)
- Built with [Astro](https://astro.build)
- Icons by [Lucide](https://lucide.dev)
- Animation inspired by [ReactBits](https://reactbits.dev)

## 💬 Support

- 📧 Email: hilal@hilaltechnologic.com
- 📖 Docs: [Documentation](/docs)
- 📝 License: [View License](./LICENSE.md)

---

<div align="center">

Made with ❤️ by [Hilal Technologic](https://hilaltechnologic.com)

**[⬆ Back to Top](#-anti-gravity)**

</div>
