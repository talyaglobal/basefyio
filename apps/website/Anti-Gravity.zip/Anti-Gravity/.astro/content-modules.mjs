
export default new Map([
["src/content/blog/design-system-best-practices.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fblog%2Fdesign-system-best-practices.mdx&astroContentModuleFlag=true")],
["src/content/blog/getting-started-with-anti-gravity.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fblog%2Fgetting-started-with-anti-gravity.mdx&astroContentModuleFlag=true")],
["src/content/blog/performance-optimization-tips.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fblog%2Fperformance-optimization-tips.mdx&astroContentModuleFlag=true")],
["src/content/docs/components.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fdocs%2Fcomponents.mdx&astroContentModuleFlag=true")],
["src/content/docs/installation.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fdocs%2Finstallation.mdx&astroContentModuleFlag=true")],
["src/content/docs/introduction.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fdocs%2Fintroduction.mdx&astroContentModuleFlag=true")],
["src/content/docs/theming.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fdocs%2Ftheming.mdx&astroContentModuleFlag=true")]]);
		